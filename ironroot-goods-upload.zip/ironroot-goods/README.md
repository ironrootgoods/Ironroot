# Ironroot Goods — One‑page Storefront (Next.js + Stripe Checkout)

This project is built to deploy on **Vercel** and take payments with **Stripe Checkout**.

## What’s included
- 1‑page storefront (grey/black)
- Cart drawer
- Stripe card checkout (supports promo codes)
- Collect UK shipping address at checkout
- Collections page
- Ingredients & allergens page
- Stripe webhook → order confirmation email (via SMTP)

## Quick start (computer)
1) Install deps:
```bash
npm install
```

2) Create `.env.local` (copy from `.env.example`) and fill in keys:
```bash
cp .env.example .env.local
```

3) Run:
```bash
npm run dev
```

## Stripe setup
1) Create Products + Prices in **GBP** (Test mode first).
2) Copy each `price_...` into `src/lib/products.ts`.

## Webhook setup (for order emails)
Stripe Dashboard → Developers → Webhooks:
- Endpoint: `https://YOURDOMAIN.com/api/webhook`
- Event: `checkout.session.completed`
- Copy the signing secret to `STRIPE_WEBHOOK_SECRET`.

## Vercel setup (phone-friendly)
- Put this repo on GitHub
- Vercel → New Project → Import repo → Deploy
- Vercel Project → Settings → Environment Variables:
  - STRIPE_SECRET_KEY
  - STRIPE_WEBHOOK_SECRET
  - NEXT_PUBLIC_SITE_URL (your deployed URL)
  - SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / FROM_EMAIL
- Redeploy after adding env vars
