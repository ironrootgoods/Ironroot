import "./globals.css";

export const metadata = {
  title: "Ironroot Goods",
  description: "Soap bars and gift sets — crafted with care."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
