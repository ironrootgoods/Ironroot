import { PRODUCTS } from "@/lib/products";

export default function IngredientsPage() {
  return (
    <main style={styles.page}>
      <header style={styles.header}>
        <a href="/" style={styles.link}>← Back</a>
        <h1 style={styles.h1}>Ingredients & Allergens</h1>
        <a href="/collections" style={styles.link}>Collections</a>
      </header>

      <section style={styles.block}>
        <h2 style={styles.h2}>Important</h2>
        <p style={styles.p}>
          This page is a template for transparency. Please replace the ingredient text with your exact
          ingredients (INCI names if applicable), allergens, and usage guidance for each product.
        </p>
        <ul style={styles.ul}>
          <li>Patch test recommended.</li>
          <li>Avoid contact with eyes.</li>
          <li>Discontinue use if irritation occurs.</li>
          <li>Keep out of reach of children.</li>
        </ul>
      </section>

      <section style={styles.block}>
        <h2 style={styles.h2}>Product ingredient cards</h2>

        <div style={styles.grid}>
          {PRODUCTS.map((p) => (
            <div key={p.id} style={styles.card}>
              <div style={styles.cardTitle}>{p.name}</div>
              <div style={styles.muted}>Category: {p.category} • Collection: {p.collection}</div>

              <div style={styles.label}>Ingredients (edit me)</div>
              <div style={styles.box}>
                Example: Melt &amp; Pour base (…), Fragrance/Essential oil (…), Colorant (…)
              </div>

              <div style={styles.label}>Scent notes (edit me)</div>
              <div style={styles.box}>Example: Warm honey + soft oats</div>

              <div style={styles.label}>Potential allergens (edit me)</div>
              <div style={styles.box}>Example: Limonene, Linalool (if present in fragrance)</div>
            </div>
          ))}
        </div>
      </section>

      <footer style={styles.footer}>
        <div>Questions? Email: inkypage.24@gmail.com</div>
      </footer>
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#0b0c0f", color: "#f2f2f2", padding: 22, fontFamily: "system-ui" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, maxWidth: 1100, margin: "0 auto 18px" },
  h1: { margin: 0, fontSize: 22, letterSpacing: -0.2 },
  h2: { margin: "0 0 8px" },
  link: { color: "#f2f2f2", textDecoration: "none", opacity: 0.85 },

  block: { maxWidth: 1100, margin: "0 auto 16px", border: "1px solid rgba(255,255,255,0.10)", borderRadius: 18, padding: 14, background: "rgba(255,255,255,0.03)" },
  p: { margin: 0, opacity: 0.85, lineHeight: 1.5 },
  ul: { margin: "10px 0 0", opacity: 0.8 },

  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 14, marginTop: 12 },
  card: { border: "1px solid rgba(255,255,255,0.10)", borderRadius: 18, padding: 14, background: "rgba(255,255,255,0.03)" },
  cardTitle: { fontWeight: 900, marginBottom: 6 },
  muted: { opacity: 0.7, fontSize: 12, marginBottom: 10 },

  label: { fontSize: 12, opacity: 0.8, marginTop: 10, marginBottom: 6 },
  box: { border: "1px solid rgba(255,255,255,0.12)", borderRadius: 14, padding: 10, background: "rgba(0,0,0,0.20)", opacity: 0.9, fontSize: 13, lineHeight: 1.4 },

  footer: { maxWidth: 1100, margin: "16px auto 0", opacity: 0.75 }
};
