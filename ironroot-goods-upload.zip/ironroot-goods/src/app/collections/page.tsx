"use client";

import { useMemo, useState } from "react";
import { PRODUCTS, Collection } from "@/lib/products";

const FILTERS: (Collection | "All")[] = [
  "All",
  "Oat & Honey",
  "Charcoal",
  "Aloe Vera",
  "Turmeric & Citrus",
  "Gift Sets"
];

export default function CollectionsPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");

  const list = useMemo(() => {
    if (filter === "All") return PRODUCTS;
    return PRODUCTS.filter((p) => p.collection === filter);
  }, [filter]);

  return (
    <main style={styles.page}>
      <header style={styles.header}>
        <a href="/" style={styles.link}>← Back</a>
        <h1 style={styles.h1}>Collections</h1>
        <a href="/ingredients" style={styles.link}>Ingredients</a>
      </header>

      <div style={styles.filters}>
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              ...styles.filterBtn,
              ...(filter === f ? styles.filterBtnActive : null)
            }}
          >
            {f}
          </button>
        ))}
      </div>

      <div style={styles.grid}>
        {list.map((p) => (
          <div key={p.id} style={styles.card}>
            <img src={p.image} alt={p.name} style={styles.img} />
            <div style={styles.cardBody}>
              <div style={styles.titleRow}>
                <div style={styles.title}>{p.name}</div>
                <div style={styles.price}>£{p.priceGBP.toFixed(2)}</div>
              </div>
              <div style={styles.muted}>{p.description}</div>
              <div style={styles.badges}>
                <span style={styles.badge}>{p.category}</span>
                <span style={styles.badge}>{p.collection}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#0b0c0f", color: "#f2f2f2", padding: 22, fontFamily: "system-ui" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, maxWidth: 1100, margin: "0 auto 18px" },
  h1: { margin: 0, fontSize: 22, letterSpacing: -0.2 },
  link: { color: "#f2f2f2", textDecoration: "none", opacity: 0.85 },

  filters: { maxWidth: 1100, margin: "0 auto 16px", display: "flex", flexWrap: "wrap", gap: 10 },
  filterBtn: { borderRadius: 999, padding: "10px 12px", background: "transparent", color: "#fff", border: "1px solid rgba(255,255,255,0.16)", cursor: "pointer", opacity: 0.85 },
  filterBtnActive: { background: "rgba(255,255,255,0.10)", opacity: 1 },

  grid: { maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14 },
  card: { border: "1px solid rgba(255,255,255,0.10)", borderRadius: 18, overflow: "hidden", background: "rgba(255,255,255,0.03)" },
  img: { width: "100%", height: 180, objectFit: "cover", display: "block" },
  cardBody: { padding: 14 },
  titleRow: { display: "flex", justifyContent: "space-between", gap: 10, alignItems: "baseline" },
  title: { fontWeight: 800 },
  price: { fontWeight: 900 },
  muted: { opacity: 0.75, fontSize: 13, marginTop: 6, lineHeight: 1.35 },
  badges: { display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 },
  badge: { fontSize: 11, opacity: 0.75, border: "1px solid rgba(255,255,255,0.16)", padding: "4px 8px", borderRadius: 999 }
};
