export default function SuccessPage() {
  return (
    <main style={{ padding: 28, fontFamily: "system-ui", maxWidth: 720, margin: "0 auto" }}>
      <h1>Payment successful ✅</h1>
      <p>Thank you for your order from Ironroot Goods.</p>
      <a href="/" style={{ display: "inline-block", marginTop: 12 }}>Return to shop</a>
    </main>
  );
}
