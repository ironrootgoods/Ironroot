export default function CancelPage() {
  return (
    <main style={{ padding: 28, fontFamily: "system-ui", maxWidth: 720, margin: "0 auto" }}>
      <h1>Checkout cancelled</h1>
      <p>No worries — your cart is still here. You can try again anytime.</p>
      <a href="/" style={{ display: "inline-block", marginTop: 12 }}>Return to shop</a>
    </main>
  );
}
