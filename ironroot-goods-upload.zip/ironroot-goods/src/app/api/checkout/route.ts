import Stripe from "stripe";
import { NextResponse } from "next/server";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

type CartItem = {
  stripePriceId: string;
  quantity: number;
};

export async function POST(req: Request) {
  try {
    const { items, customerEmail } = (await req.json()) as {
      items: CartItem[];
      customerEmail?: string;
    };

    if (!process.env.STRIPE_SECRET_KEY) {
      return NextResponse.json({ error: "Missing STRIPE_SECRET_KEY" }, { status: 500 });
    }
    if (!process.env.NEXT_PUBLIC_SITE_URL) {
      return NextResponse.json({ error: "Missing NEXT_PUBLIC_SITE_URL" }, { status: 500 });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: items.map((i) => ({
        price: i.stripePriceId,
        quantity: i.quantity
      })),

      // Collect UK shipping address
      shipping_address_collection: { allowed_countries: ["GB"] },

      // Allow discount codes (Promotion codes)
      allow_promotion_codes: true,

      // Pre-fill receipt email (optional)
      customer_email: customerEmail,

      metadata: { brand: "Ironroot Goods" },

      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/cancel`
    });

    return NextResponse.json({ url: session.url });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message ?? "Checkout error" },
      { status: 500 }
    );
  }
}
