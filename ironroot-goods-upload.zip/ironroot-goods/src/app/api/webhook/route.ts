import Stripe from "stripe";
import { headers } from "next/headers";
import { NextResponse } from "next/server";
import nodemailer from "nodemailer";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

function getTransport() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || "465");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) return null;

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass }
  });
}

export async function POST(req: Request) {
  const sig = headers().get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!sig || !webhookSecret) {
    return NextResponse.json(
      { error: "Missing stripe-signature header or STRIPE_WEBHOOK_SECRET" },
      { status: 400 }
    );
  }

  const rawBody = await req.text();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;

    const to = session.customer_details?.email || session.customer_email || undefined;
    const amountTotal = session.amount_total ? (session.amount_total / 100).toFixed(2) : null;
    const currency = (session.currency || "gbp").toUpperCase();

    const ship = session.shipping_details?.address;
    const shipName = session.shipping_details?.name;

    const transporter = getTransport();
    if (transporter && to) {
      const from = process.env.FROM_EMAIL || "Ironroot Goods <no-reply@ironrootgoods.co.uk>";

      const addressLines = ship
        ? [shipName, ship.line1, ship.line2, ship.city, ship.state, ship.postal_code, ship.country]
            .filter(Boolean)
            .join("<br/>")
        : "Collected at checkout";

      await transporter.sendMail({
        from,
        to,
        subject: "Your Ironroot Goods order is confirmed",
        html: `
          <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;line-height:1.5">
            <h2 style="margin:0 0 10px">Order confirmed ✅</h2>
            <p style="margin:0 0 10px">Thank you for your order with <b>Ironroot Goods</b>.</p>
            ${amountTotal ? `<p style="margin:0 0 10px"><b>Total:</b> £${amountTotal} ${currency}</p>` : ""}
            <p style="margin:0 0 10px"><b>Shipping to:</b><br/>${addressLines}</p>
            <p style="margin:16px 0 0;opacity:.8">If you have any questions, reply to this email.</p>
          </div>
        `
      });
    }
  }

  return NextResponse.json({ received: true });
}
