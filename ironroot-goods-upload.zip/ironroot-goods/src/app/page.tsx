"use client";

import { useMemo, useState } from "react";
import { PRODUCTS, Product } from "@/lib/products";

type CartLine = { product: Product; qty: number };

export default function HomePage() {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [customerEmail, setCustomerEmail] = useState("");

  const lines: CartLine[] = useMemo(() => {
    return Object.entries(cart)
      .map(([id, qty]) => {
        const product = PRODUCTS.find((p) => p.id === id);
        return product ? { product, qty } : null;
      })
      .filter(Boolean) as CartLine[];
  }, [cart]);

  const subtotal = useMemo(() => {
    return lines.reduce((sum, l) => sum + l.product.priceGBP * l.qty, 0);
  }, [lines]);

  function addToCart(id: string) {
    setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
    setDrawerOpen(true);
  }

  function setQty(id: string, qty: number) {
    setCart((c) => {
      const next = { ...c };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  }

  async function checkout() {
    if (lines.length === 0) return;

    setLoading(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: lines.map((l) => ({
            stripePriceId: l.product.stripePriceId,
            quantity: l.qty
          })),
          customerEmail: customerEmail || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Checkout failed");

      window.location.href = data.url;
    } catch (e: any) {
      alert(e.message ?? "Checkout failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div style={styles.brand}>
          <div style={styles.logoDot} />
          <div>
            <div style={styles.brandName}>Ironroot Goods</div>
            <div style={styles.brandTag}>Soap Bars • Gift Sets</div>
          </div>
        </div>

        <nav style={styles.nav}>
          <a href="/collections" style={styles.navLink}>Collections</a>
          <a href="/ingredients" style={styles.navLink}>Ingredients</a>
          <button style={styles.cartBtn} onClick={() => setDrawerOpen(true)}>
            Cart ({lines.reduce((s, l) => s + l.qty, 0)})
          </button>
        </nav>
      </header>

      <section style={styles.hero}>
        <div style={styles.heroInner}>
          <h1 style={styles.h1}>Minimal. Clean. Gift-ready.</h1>
          <p style={styles.p}>
            Ironroot Goods makes simple, beautiful soap bars and gift sets — designed to look premium,
            feel thoughtful, and keep your brand memorable.
          </p>
          <div style={styles.heroActions}>
            <a href="#shop" style={{ ...styles.primaryBtn, textDecoration: "none" }}>
              Shop now
            </a>
            <a href="/collections" style={{ ...styles.secondaryBtn, textDecoration: "none" }}>
              Browse collections
            </a>
          </div>
        </div>
      </section>

      <section id="shop" style={styles.section}>
        <div style={styles.sectionHead}>
          <h2 style={styles.h2}>Shop</h2>
          <div style={styles.muted}>Secure card checkout • UK address collected</div>
        </div>

        <div style={styles.grid}>
          {PRODUCTS.map((p) => (
            <div key={p.id} style={styles.card}>
              <div style={styles.imgWrap}>
                <img src={p.image} alt={p.name} style={styles.img} />
              </div>
              <div style={styles.cardBody}>
                <div style={styles.cardTop}>
                  <div>
                    <div style={styles.badge}>{p.collection}</div>
                    <div style={styles.cardTitle}>{p.name}</div>
                    <div style={styles.cardDesc}>{p.description}</div>
                  </div>
                  <div style={styles.price}>£{p.priceGBP.toFixed(2)}</div>
                </div>

                <button style={styles.addBtn} onClick={() => addToCart(p.id)}>
                  Add to cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section style={styles.sectionAlt}>
        <div style={{ ...styles.section, paddingTop: 0, paddingBottom: 0 }}>
          <h2 style={styles.h2}>About Ironroot Goods</h2>
          <p style={styles.p}>
            Clean design, premium feel. Each gift set can include your insert card with ingredients
            and scent details — perfect for transparency and a luxe unboxing.
          </p>

          <div style={styles.fourGrid}>
            <div style={styles.smallCard}>
              <div style={styles.smallTitle}>Brand-first</div>
              <div style={styles.smallText}>Minimal packaging that feels high-end.</div>
            </div>
            <div style={styles.smallCard}>
              <div style={styles.smallTitle}>Gift-ready</div>
              <div style={styles.smallText}>Bars + sets that look like a finished product.</div>
            </div>
            <div style={styles.smallCard}>
              <div style={styles.smallTitle}>Clear info</div>
              <div style={styles.smallText}>Ingredients & allergens page included.</div>
            </div>
            <div style={styles.smallCard}>
              <div style={styles.smallTitle}>Secure checkout</div>
              <div style={styles.smallText}>Card payments via Stripe Checkout.</div>
            </div>
          </div>
        </div>
      </section>

      <footer style={styles.footer}>
        <div>© {new Date().getFullYear()} Ironroot Goods</div>
        <div style={styles.footerLinks}>
          <a style={styles.footerLink} href="/collections">Collections</a>
          <a style={styles.footerLink} href="/ingredients">Ingredients</a>
          <a style={styles.footerLink} href="mailto:inkypage.24@gmail.com">inkypage.24@gmail.com</a>
        </div>
      </footer>

      {drawerOpen && (
        <div style={styles.drawerOverlay} onClick={() => setDrawerOpen(false)}>
          <div style={styles.drawer} onClick={(e) => e.stopPropagation()}>
            <div style={styles.drawerHead}>
              <div style={styles.drawerTitle}>Your Cart</div>
              <button style={styles.drawerClose} onClick={() => setDrawerOpen(false)}>
                ✕
              </button>
            </div>

            {lines.length === 0 ? (
              <div style={styles.emptyCart}>Your cart is empty.</div>
            ) : (
              <div style={styles.cartList}>
                {lines.map(({ product, qty }) => (
                  <div key={product.id} style={styles.cartRow}>
                    <div style={{ flex: 1 }}>
                      <div style={styles.cartName}>{product.name}</div>
                      <div style={styles.cartMuted}>£{product.priceGBP.toFixed(2)} each</div>
                    </div>

                    <div style={styles.qty}>
                      <button style={styles.qtyBtn} onClick={() => setQty(product.id, qty - 1)}>-</button>
                      <div style={styles.qtyNum}>{qty}</div>
                      <button style={styles.qtyBtn} onClick={() => setQty(product.id, qty + 1)}>+</button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div style={styles.drawerFooter}>
              <input
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                placeholder="Email for receipt"
                style={styles.emailInput}
              />

              <div style={styles.subtotalRow}>
                <div style={styles.cartMuted}>Subtotal</div>
                <div style={styles.subtotal}>£{subtotal.toFixed(2)}</div>
              </div>

              <button
                style={{ ...styles.checkoutBtn, opacity: lines.length === 0 || loading ? 0.6 : 1 }}
                disabled={lines.length === 0 || loading}
                onClick={checkout}
              >
                {loading ? "Redirecting…" : "Checkout"}
              </button>

              <div style={styles.cartNote}>
                UK shipping address is collected at checkout. Promo codes supported.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#0b0c0f", color: "#f2f2f2", fontFamily: "ui-sans-serif, system-ui, -apple-system" },
  header: { position: "sticky", top: 0, zIndex: 20, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 22px", background: "rgba(11,12,15,0.8)", backdropFilter: "blur(10px)", borderBottom: "1px solid rgba(255,255,255,0.08)" },
  brand: { display: "flex", gap: 12, alignItems: "center" },
  logoDot: { width: 14, height: 14, borderRadius: 999, background: "#bfbfbf" },
  brandName: { fontSize: 16, fontWeight: 700, letterSpacing: 0.2 },
  brandTag: { fontSize: 12, opacity: 0.75 },
  nav: { display: "flex", gap: 12, alignItems: "center" },
  navLink: { color: "#fff", textDecoration: "none", opacity: 0.85, fontSize: 13 },
  cartBtn: { border: "1px solid rgba(255,255,255,0.16)", background: "transparent", color: "#fff", padding: "10px 12px", borderRadius: 12, cursor: "pointer" },

  hero: { padding: "70px 22px 30px" },
  heroInner: { maxWidth: 980, margin: "0 auto", border: "1px solid rgba(255,255,255,0.10)", borderRadius: 22, padding: "44px 28px", background: "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))" },
  h1: { fontSize: 44, lineHeight: 1.05, margin: 0, letterSpacing: -0.6 },
  h2: { fontSize: 26, margin: "0 0 10px", letterSpacing: -0.2 },
  p: { marginTop: 12, fontSize: 16, opacity: 0.86, maxWidth: 740 },
  heroActions: { display: "flex", gap: 12, marginTop: 18, flexWrap: "wrap" },
  primaryBtn: { background: "#f2f2f2", color: "#0b0c0f", padding: "12px 14px", borderRadius: 14, fontWeight: 700 },
  secondaryBtn: { border: "1px solid rgba(255,255,255,0.18)", color: "#fff", padding: "12px 14px", borderRadius: 14 },

  section: { maxWidth: 1100, margin: "0 auto", padding: "28px 22px 60px" },
  sectionAlt: { background: "#08090c", borderTop: "1px solid rgba(255,255,255,0.06)", borderBottom: "1px solid rgba(255,255,255,0.06)" },
  sectionHead: { display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 12, flexWrap: "wrap", marginBottom: 16 },
  muted: { fontSize: 12, opacity: 0.65 },

  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14 },
  card: { border: "1px solid rgba(255,255,255,0.10)", borderRadius: 18, overflow: "hidden", background: "rgba(255,255,255,0.03)" },
  imgWrap: { height: 180, overflow: "hidden", background: "rgba(255,255,255,0.03)" },
  img: { width: "100%", height: "100%", objectFit: "cover", display: "block" },
  cardBody: { padding: 14 },
  cardTop: { display: "flex", justifyContent: "space-between", gap: 10 },
  badge: { fontSize: 11, opacity: 0.7, border: "1px solid rgba(255,255,255,0.16)", display: "inline-block", padding: "4px 8px", borderRadius: 999, marginBottom: 8 },
  cardTitle: { fontSize: 16, fontWeight: 800, marginBottom: 6 },
  cardDesc: { fontSize: 13, opacity: 0.78, lineHeight: 1.35 },
  price: { fontSize: 15, fontWeight: 800, whiteSpace: "nowrap" },
  addBtn: { width: "100%", marginTop: 12, borderRadius: 14, padding: "11px 12px", cursor: "pointer", border: "1px solid rgba(255,255,255,0.16)", background: "rgba(255,255,255,0.06)", color: "#fff", fontWeight: 700 },

  fourGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12, marginTop: 16, paddingBottom: 30 },
  smallCard: { border: "1px solid rgba(255,255,255,0.10)", borderRadius: 18, padding: 14, background: "rgba(255,255,255,0.03)" },
  smallTitle: { fontWeight: 800, marginBottom: 6 },
  smallText: { fontSize: 13, opacity: 0.78 },

  footer: { maxWidth: 1100, margin: "0 auto", padding: "24px 22px 36px", display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", opacity: 0.85 },
  footerLinks: { display: "flex", gap: 14 },
  footerLink: { color: "#f2f2f2", textDecoration: "none", opacity: 0.85 },

  drawerOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", display: "flex", justifyContent: "flex-end", zIndex: 50 },
  drawer: { width: "min(420px, 92vw)", height: "100%", background: "#0b0c0f", borderLeft: "1px solid rgba(255,255,255,0.10)", padding: 16, display: "flex", flexDirection: "column" },
  drawerHead: { display: "flex", alignItems: "center", justifyContent: "space-between", paddingBottom: 10, borderBottom: "1px solid rgba(255,255,255,0.08)" },
  drawerTitle: { fontSize: 16, fontWeight: 800 },
  drawerClose: { border: "1px solid rgba(255,255,255,0.16)", background: "transparent", color: "#fff", borderRadius: 12, padding: "8px 10px", cursor: "pointer" },

  emptyCart: { padding: 18, opacity: 0.8 },
  cartList: { paddingTop: 10, display: "flex", flexDirection: "column", gap: 10, overflow: "auto" },
  cartRow: { display: "flex", gap: 10, alignItems: "center", border: "1px solid rgba(255,255,255,0.10)", borderRadius: 16, padding: 12, background: "rgba(255,255,255,0.03)" },
  cartName: { fontWeight: 800, fontSize: 13 },
  cartMuted: { fontSize: 12, opacity: 0.65 },

  qty: { display: "flex", alignItems: "center", gap: 8 },
  qtyBtn: { width: 34, height: 34, borderRadius: 12, border: "1px solid rgba(255,255,255,0.16)", background: "transparent", color: "#fff", cursor: "pointer", fontSize: 16 },
  qtyNum: { width: 20, textAlign: "center", fontWeight: 800 },

  drawerFooter: { marginTop: "auto", borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: 12, display: "flex", flexDirection: "column", gap: 10 },
  emailInput: { width: "100%", padding: "10px 12px", borderRadius: 14, border: "1px solid rgba(255,255,255,0.16)", background: "rgba(255,255,255,0.06)", color: "#fff", outline: "none" },
  subtotalRow: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  subtotal: { fontWeight: 900 },
  checkoutBtn: { borderRadius: 14, padding: "12px 12px", cursor: "pointer", border: "none", background: "#f2f2f2", color: "#0b0c0f", fontWeight: 900 },
  cartNote: { fontSize: 11, opacity: 0.65 }
};
