export type Category = "Soap Bar" | "Gift Set";
export type Collection =
  | "Oat & Honey"
  | "Charcoal"
  | "Aloe Vera"
  | "Turmeric & Citrus"
  | "Gift Sets";

export type Product = {
  id: string;
  name: string;
  shortName: string;
  description: string;
  image: string;
  priceGBP: number;
  stripePriceId: string; // replace with your Stripe Price IDs
  category: Category;
  collection: Collection;
};

export const PRODUCTS: Product[] = [
  {
    id: "oat-honey",
    name: "Oat & Honey Bar",
    shortName: "Oat & Honey",
    description: "Warm, comforting and creamy — a soft, everyday bar.",
    image:
      "https://images.unsplash.com/photo-1615396899839-c99c121888b0?auto=format&fit=crop&w=1400&q=80",
    priceGBP: 8.0,
    stripePriceId: "price_XXXXXXXXXXXX", // <-- replace
    category: "Soap Bar",
    collection: "Oat & Honey"
  },
  {
    id: "charcoal-bliss",
    name: "Charcoal Bliss",
    shortName: "Charcoal",
    description: "Bold and clean — a deep, modern bar with a fresh finish.",
    image:
      "https://images.unsplash.com/photo-1607006344380-b6775a0824ce?auto=format&fit=crop&w=1400&q=80",
    priceGBP: 10.0,
    stripePriceId: "price_XXXXXXXXXXXX", // <-- replace
    category: "Soap Bar",
    collection: "Charcoal"
  },
  {
    id: "aloe-vera",
    name: "Aloe Vera Bar",
    shortName: "Aloe Vera",
    description: "Simple, soothing, and clean — made for a fresh feel.",
    image:
      "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=1400&q=80",
    priceGBP: 8.0,
    stripePriceId: "price_XXXXXXXXXXXX", // <-- replace
    category: "Soap Bar",
    collection: "Aloe Vera"
  },
  {
    id: "turmeric-orange",
    name: "Turmeric & Orange Bar",
    shortName: "Turmeric & Orange",
    description: "Bright citrus with a warm golden vibe — clean and uplifting.",
    image:
      "https://images.unsplash.com/photo-1585232351009-aa87416fca90?auto=format&fit=crop&w=1400&q=80",
    priceGBP: 8.0,
    stripePriceId: "price_XXXXXXXXXXXX", // <-- replace
    category: "Soap Bar",
    collection: "Turmeric & Citrus"
  },
  {
    id: "signature-gift-set",
    name: "Signature Gift Set",
    shortName: "Gift Set",
    description: "A premium set — 2 bars + insert card. Ready to gift.",
    image:
      "https://images.unsplash.com/photo-1615486511484-92e172aff8a6?auto=format&fit=crop&w=1400&q=80",
    priceGBP: 24.99,
    stripePriceId: "price_XXXXXXXXXXXX", // <-- replace
    category: "Gift Set",
    collection: "Gift Sets"
  }
];
